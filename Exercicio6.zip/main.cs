using System;

class Program
{
    static void Main(string[] args)
    {
        // Ler os dois números reais
        Console.Write("Digite o valor de A: ");
        double A = Convert.ToDouble(Console.ReadLine());

        Console.Write("Digite o valor de B: ");
        double B = Convert.ToDouble(Console.ReadLine());

        // Trocar os valores entre as variáveis A e B usando uma variável auxiliar
        double temp = A;
        A = B;
        B = temp;

        // Imprimir os valores finais
        Console.WriteLine($"Valor de A após a troca: {A}");
        Console.WriteLine($"Valor de B após a troca: {B}");
    }
}
