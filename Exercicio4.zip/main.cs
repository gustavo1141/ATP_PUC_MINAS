using System;

class Program
{
    static void Main(string[] args)
    {
        // Solicita as coordenadas dos dois pontos ao usuário
        Console.WriteLine("Digite as coordenadas do primeiro ponto (x1, y1):");
        Console.Write("x1: ");
        double x1 = double.Parse(Console.ReadLine());
        Console.Write("y1: ");
        double y1 = double.Parse(Console.ReadLine());

        Console.WriteLine("\nDigite as coordenadas do segundo ponto (x2, y2):");
        Console.Write("x2: ");
        double x2 = double.Parse(Console.ReadLine());
        Console.Write("y2: ");
        double y2 = double.Parse(Console.ReadLine());

        // Calcula a distância entre os pontos
        double distancia = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

        // Imprime a distância entre os pontos
        Console.WriteLine($"\nA distância entre os pontos ({x1},{y1}) e ({x2},{y2}) é: {distancia}");
    }
}
