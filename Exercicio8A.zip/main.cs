using System;

class Program
{
    static void Main(string[] args)
    {
        // Esta linha irá ler o número da conta corrente
        Console.Write("Digite o número da conta corrente (3 dígitos): ");
        int numeroConta = Convert.ToInt32(Console.ReadLine());

        // Aqui vai verificar se o número tem exatamente 3 dígitos
        if (numeroConta >= 100 && numeroConta <= 999)
        {
            // Aqui irá calcular o inverso do número
            int inverso = InverterNumero(numeroConta);

            // Aqui irá somar o número da conta com seu inverso
            int soma = numeroConta + inverso;

            // Ja nessa linha ira calcular o dígito verificador
            int digitoVerificador = soma % 10;

            // Aqui ira imprimir o dígito verificador
            Console.WriteLine($"O dígito verificador da conta corrente é: {digitoVerificador}");
        }
        else
        {
            Console.WriteLine("O número da conta corrente deve ter 3 dígitos.");
        }
    }

    // e esta é a função para inverter um número
    static int InverterNumero(int numero)
    {
        int inverso = 0;
        while (numero > 0)
        {
            int digito = numero % 10;
            inverso = inverso * 10 + digito;
            numero /= 10;
        }
        return inverso;
    }
}
