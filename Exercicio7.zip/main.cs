using System;

class Program
{
    static void Main(string[] args)
    {
        // Esta linha vai ler a quantidade de dias sem acidentes
        Console.Write("Digite a quantidade de dias sem acidentes: ");
        int diasSemAcidentes = Convert.ToInt32(Console.ReadLine());

        // Esta linha vai calcular os anos, meses e dias
        int anos = diasSemAcidentes / 365;
        int meses = (diasSemAcidentes % 365) / 30;
        int dias = (diasSemAcidentes % 365) % 30;

        // Esta linha vai mostrar os dias sem acidentes separados em anos, meses e dias
        Console.WriteLine($"Saída: {anos} anos, {meses} meses e {dias} dias");
    }
}
