using System;

class Program
{
    static void Main(string[] args)
    {
        // Ler o número da conta corrente
        Console.Write("Digite o número da conta corrente (3 dígitos): ");
        int numeroConta = Convert.ToInt32(Console.ReadLine());

        // Verificar se o número tem exatamente 3 dígitos
        if (numeroConta >= 100 && numeroConta <= 999)
        {
            // Calcular a soma das multiplicações
            int somaMultiplicacoes = CalcularSomaMultiplicacoes(numeroConta);

            // Calcular o dígito verificador
            int digitoVerificador = somaMultiplicacoes % 10;

            // Imprimir o dígito verificador
            Console.WriteLine($"O dígito verificador da conta corrente é: {digitoVerificador}");
        }
        else
        {
            Console.WriteLine("O número da conta corrente deve ter 3 dígitos.");
        }
    }

    // Função para calcular a soma das multiplicações
    static int CalcularSomaMultiplicacoes(int numero)
    {
        int soma = 0;
        int posicao = 0;

        while (numero > 0)
        {
            int digito = numero % 10;
            soma += digito * (posicao + 1); // Posição inicia em 1, não em 0 como no caso anterior
            numero /= 10;
            posicao++;
        }

        return soma;
    }
}
