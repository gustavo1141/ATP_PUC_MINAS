using System;

class Program
{
    static void Main(string[] args)
    {
        // Para começar essa linha vai ler o valor do salário mínimo
        Console.Write("Digite o valor do salário mínimo: ");
        double salarioMinimo = Convert.ToDouble(Console.ReadLine());

        // irá ler a quantidade de kilowatt gasta em uma residência
        Console.Write("Digite a quantidade de kilowatt gasta: ");
        int quantidadeKilowatt = Convert.ToInt32(Console.ReadLine());

        // vai caalcular o valor em reais de cada kilowatt
        double valorPorKilowatt = salarioMinimo / 7 / 100;

        // irá calcular o valor em reais a ser pago
        double valorTotal = valorPorKilowatt * quantidadeKilowatt;

        // vai calcular o novo valor a ser pago com desconto de 10%
        double valorComDesconto = valorTotal * 0.9;

        // Mostrar os resultados
        Console.WriteLine($"Valor em reais de cada kilowatt: R$ {valorPorKilowatt:F2}");
        Console.WriteLine($"Valor total a ser pago: R$ {valorTotal:F2}");
        Console.WriteLine($"Novo valor a ser pago com desconto de 10%: R$ {valorComDesconto:F2}");
    }
}
