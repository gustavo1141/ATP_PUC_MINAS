using System;

class Program
{
    static void Main(string[] args)// siga abaixo os comentários sobre o código
    {
        // Aq será onde o usuário terá q insirir a base do retângulo
        Console.Write("Insira a base do retângulo: ");
        double baseRetangulo = Convert.ToDouble(Console.ReadLine());

        // Aqui solicita ao usuário que insira a altura do retângulo
        Console.Write("Insira a altura do retângulo: ");
        double alturaRetangulo = Convert.ToDouble(Console.ReadLine());

        // Calcula o perímetro do retângulo
        double perimetro = 2 * (baseRetangulo + alturaRetangulo);

        // Calcula a área do retângulo
        double area = baseRetangulo * alturaRetangulo;

        // Calcula a diagonal do retângulo usando o teorema de Pitágoras
        double diagonal = Math.Sqrt(Math.Pow(baseRetangulo, 2) + Math.Pow(alturaRetangulo, 2));

        // Exibe os resultados
        Console.WriteLine("\nPerímetro do retângulo: " + perimetro);
        Console.WriteLine("Área do retângulo: " + area);
        Console.WriteLine("Diagonal do retângulo: " + diagonal);

        Console.ReadLine(); // Mantém a janela do console aberta até que o usuário pressione Enter
    }
}
