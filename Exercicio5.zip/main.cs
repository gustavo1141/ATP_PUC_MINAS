using System;

class Program
{
    static void Main(string[] args)
    {
        // nessa linha vai ler o valor constante da aplicação mensal
        Console.Write("Digite o valor da aplicação mensal: ");
        double p = Convert.ToDouble(Console.ReadLine());

        // Irá ler a taxa de juros
        Console.Write("Digite a taxa de juros (em decimal): ");
        double i = Convert.ToDouble(Console.ReadLine());

        // aqui vai ler o número de meses
        Console.Write("Digite o número de meses: ");
        int n = Convert.ToInt32(Console.ReadLine());

        // aq vai realizar o calculo do rendimento
        double rendimento = p * ((Math.Pow(1 + i, n) - 1) / i);

        // e para finalizar aqui vai mostrar o rendimento
        Console.WriteLine($"O rendimento da aplicação é: R$ {rendimento:F2}");
    }
}
