using System;

class Program
{
    static void Main(string[] args)
    {
        // Solicita ao usuário que insira o valor do primeiro cateto
        Console.Write("Insira o valor do primeiro cateto: ");
        double cateto1 = Convert.ToDouble(Console.ReadLine());

        // Solicita ao usuário que insira o valor do segundo cateto
        Console.Write("Insira o valor do segundo cateto: ");
        double cateto2 = Convert.ToDouble(Console.ReadLine());

        // Calcula a hipotenusa usando o teorema de Pitágoras
        double hipotenusa = Math.Sqrt(Math.Pow(cateto1, 2) + Math.Pow(cateto2, 2));

        // Exibe a hipotenusa
        Console.WriteLine("\nA hipotenusa do triângulo retângulo é: " + hipotenusa);

        Console.ReadLine(); 
    }
}
