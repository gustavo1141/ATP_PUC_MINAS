using System;

class Program
{
    static void Main(string[] args)
    {
        // Solicita ao usuário para inserir o número da conta corrente
        Console.Write("Digite o número da conta corrente (3 dígitos): ");
        string numeroConta = Console.ReadLine();

        // Verifica se o número da conta corrente tem 3 dígitos
        if (numeroConta.Length != 3)
        {
            Console.WriteLine("O número da conta corrente deve ter 3 dígitos.");
            return;
        }

        // Calcula o dígito verificador
        int soma = 0;
        for (int i = 0; i < numeroConta.Length; i++)
        {
            soma += int.Parse(numeroConta[i].ToString());
        }

        // Impriime o dígito verificador
        int digitoVerificador = soma % 10;
        Console.WriteLine($"O dígito verificador da conta corrente é: {digitoVerificador}");
    }
}
